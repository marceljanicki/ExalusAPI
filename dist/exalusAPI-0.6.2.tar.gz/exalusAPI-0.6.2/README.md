# exalusAPI

A simple wrapper for [Exalus Home](https://www.tr7.pl/), created specifically for [HomeAssistant](https://www.home-assistant.io/) integration.

